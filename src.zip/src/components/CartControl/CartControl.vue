<template>
    <div class="cartcontrol">
      <transition name="fade">
        <div class="iconfont icon-remove_circle_outline" @click.stop='addCount(false)' v-if='food.count'>
        </div>
      </transition>
        <div class="cart-count" v-if="food.count">{{food.count}}</div>
        <div class="iconfont icon-add_circle" @click.stop='addCount(true)'></div>
    </div>
</template>
<script>
  import throttle from 'lodash/throttle'
    export default {
        props:{
          food:Object
        },
        methods:{
            addCount: throttle(function(isAdd){
                this.$store.dispatch('updateFoodCount',{isAdd,food:this.food})           
            },1000)
        }
    }
</script>
<style lang="stylus" rel="stylesheet/stylus">
  @import "../../common/stylus/mixins.styl"

  .cartcontrol
    font-size: 0
    .cart-decrease
      display: inline-block
      padding: 6px
      line-height: 24px
      font-size: 24px
      color: rgb(0, 160, 220)

    .icon-remove_circle_outline
      display: inline-block
      padding 6px
      line-height 24px
      font-size 24px
      color $green
      
      &.fade-enter-active,&.fade-leave-active
        transition all 0.2s
      &.fade-enter,&.fade-leave-to
        transform translateX(20px) rotate(180deg)
        opacity 0
    .cart-count
      display: inline-block
      vertical-align: top
      width: 12px
      padding-top: 6px
      line-height: 24px
      text-align: center
      font-size: 10px
      color: rgb(147, 153, 159)
    .icon-add_circle
      display: inline-block
      padding: 6px
      line-height: 24px
      font-size: 24px
      color $green
</style>
