<template>
<div>
Info
</div>
</template>
<script>
export default {

}
</script>
<style lang='stylus' scoped>

</style>